#!/bin/bash

zip -r "InstaBot.zip" * -x "InstaBot.zip"